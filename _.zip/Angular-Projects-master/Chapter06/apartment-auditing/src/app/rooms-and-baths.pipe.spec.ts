import { RoomsAndBathsPipe } from './rooms-and-baths.pipe';

describe('RoomsAndBathsPipe', () => {
  it('create an instance', () => {
    const pipe = new RoomsAndBathsPipe();
    expect(pipe).toBeTruthy();
  });
});
